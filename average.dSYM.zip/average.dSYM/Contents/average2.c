#include<stdio.h>
int main (){
    int num;
    printf("Enter the number of elements :");
    scanf("%d",&num);
    int arr[num];
    int sum = 0 ;
    printf("Enter the  elements :");

    
    for(int i = 0;i<num;i++){
    scanf("%d",&arr[i]);
    sum +=arr[i];
    }
    printf("The sum of the number :%d\n",sum);
    int average =sum/num;
    printf("the average value is :%d",average);
    scanf("%d",&average);
    return 0;
}